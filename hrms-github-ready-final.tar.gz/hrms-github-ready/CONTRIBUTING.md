# Contributing to HRMS

We love your input! We want to make contributing to HRMS as easy and transparent as possible, whether it's:

- Reporting a bug
- Discussing the current state of the code
- Submitting a fix
- Proposing new features
- Becoming a maintainer

## Development Process

We use GitHub to host code, to track issues and feature requests, as well as accept pull requests.

## Pull Requests

Pull requests are the best way to propose changes to the codebase. We actively welcome your pull requests:

1. Fork the repo and create your branch from `main`.
2. If you've added code that should be tested, add tests.
3. If you've changed APIs, update the documentation.
4. Ensure the test suite passes.
5. Make sure your code lints.
6. Issue that pull request!

## Any contributions you make will be under the MIT Software License

In short, when you submit code changes, your submissions are understood to be under the same [MIT License](http://choosealicense.com/licenses/mit/) that covers the project. Feel free to contact the maintainers if that's a concern.

## Report bugs using GitHub's [issue tracker](../../issues)

We use GitHub issues to track public bugs. Report a bug by [opening a new issue](../../issues/new); it's that easy!

## Write bug reports with detail, background, and sample code

**Great Bug Reports** tend to have:

- A quick summary and/or background
- Steps to reproduce
  - Be specific!
  - Give sample code if you can
- What you expected would happen
- What actually happens
- Notes (possibly including why you think this might be happening, or stuff you tried that didn't work)

## Development Setup

### Prerequisites

- Python 3.8+
- Node.js 14+
- PostgreSQL
- Docker (optional but recommended)

### Backend Setup

1. Clone the repository
```bash
git clone <your-fork>
cd hrms-app/backend
```

2. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies
```bash
pip install -r requirements.txt
```

4. Set up environment variables
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. Run database migrations
```bash
python create_tables.py
```

6. Start the development server
```bash
uvicorn app.main:app --reload
```

### Frontend Setup

1. Navigate to frontend directory
```bash
cd ../frontend
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm start
```

## Code Style

### Python (Backend)

- Follow PEP 8
- Use type hints where possible
- Write docstrings for functions and classes
- Use meaningful variable and function names

### JavaScript (Frontend)

- Use ES6+ features
- Follow React best practices
- Use meaningful component and variable names
- Write comments for complex logic

### General

- Write clear, concise commit messages
- Keep functions small and focused
- Add tests for new features
- Update documentation when needed

## Testing

### Backend Tests

```bash
cd backend
python -m pytest tests/
```

### Frontend Tests

```bash
cd frontend
npm test
```

## Documentation

- Update README.md if you change functionality
- Add docstrings to new functions
- Update API documentation for new endpoints
- Include examples in documentation

## Code Review Process

1. All submissions require review
2. We may suggest changes, improvements, or alternatives
3. Once approved, we'll merge your pull request

## Community

- Be respectful and inclusive
- Help others learn and grow
- Share knowledge and best practices
- Follow our code of conduct

## Getting Help

- Check existing issues and documentation first
- Ask questions in issues or discussions
- Reach out to maintainers if needed

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes for significant contributions
- Special thanks for major features or fixes

Thank you for contributing to HRMS! 🎉

