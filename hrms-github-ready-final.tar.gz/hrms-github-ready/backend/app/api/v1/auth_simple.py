from fastapi import APIRouter, HTTPException, status
from app.schemas.auth import LoginRequest, Token
from app.core.security import create_access_token, verify_password, get_password_hash

router = APIRouter(prefix="/auth", tags=["auth"])

# Mock users for demonstration (in production, this would come from database)
MOCK_USERS = {
    "admin@example.com": {
        "id": 1,
        "email": "admin@example.com",
        "password_hash": get_password_hash("admin123"),
        "role": "admin",
        "first_name": "Admin",
        "last_name": "User"
    },
    "john.doe@example.com": {
        "id": 2,
        "email": "john.doe@example.com", 
        "password_hash": get_password_hash("employee123"),
        "role": "employee",
        "first_name": "John",
        "last_name": "Doe"
    }
}

@router.post("/login", response_model=Token)
async def login(form_data: LoginRequest):
    """
    Login endpoint that authenticates user and returns JWT token
    """
    # Find user by email
    user = MOCK_USERS.get(form_data.email)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Verify password
    if not verify_password(form_data.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Create access token
    access_token = create_access_token(
        data={
            "sub": str(user["id"]),
            "email": user["email"],
            "role": user["role"],
            "username": user["email"]
        }
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer"
    }

@router.get("/me")
async def get_user():
    """
    Get current authenticated user information
    """
    return {"message": "User info endpoint - requires authentication"}

@router.get("/test")
async def test_endpoint():
    """
    Test endpoint to verify API is working
    """
    return {"message": "Auth API is working!", "users": list(MOCK_USERS.keys())}

