#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from passlib.context import CryptContext
import psycopg2

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def update_passwords():
    """Update user passwords with correct hashes"""
    try:
        # Connect to database
        conn = psycopg2.connect(
            host="localhost",
            database="hrms_db",
            user="hrms_user",
            password="hrms_pass"
        )
        cur = conn.cursor()
        
        # Hash the passwords
        admin_password = hash_password("admin123")
        employee_password = hash_password("employee123")
        
        # Update admin password
        cur.execute(
            "UPDATE employees SET password = %s WHERE email = %s",
            (admin_password, "admin@example.com")
        )
        
        # Update employee password
        cur.execute(
            "UPDATE employees SET password = %s WHERE email = %s",
            (employee_password, "john.doe@example.com")
        )
        
        conn.commit()
        print("Passwords updated successfully!")
        print(f"Admin password hash: {admin_password}")
        print(f"Employee password hash: {employee_password}")
        
    except Exception as e:
        print(f"Error updating passwords: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    update_passwords()

