#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.core.database import engine, Base
from app.models.employee import Employee, Department, Role, Document
from app.models.attendance import Attendance, LeaveRequest, LeaveBalance, Holiday
from app.models.payroll import Salary, Payslip
from app.models.performance import PerformanceReview, Goal

def create_tables():
    """Create all database tables"""
    try:
        Base.metadata.create_all(bind=engine)
        print("All tables created successfully!")
    except Exception as e:
        print(f"Error creating tables: {e}")

if __name__ == "__main__":
    create_tables()

