-- Departments (already inserted, but adding for completeness)
INSERT INTO departments (name) VALUES ('IT'), ('HR'), ('Finance') ON CONFLICT (name) DO NOTHING;

-- Roles (already inserted, but adding for completeness)
INSERT INTO roles (name) VALUES ('Developer'), ('Manager'), ('HR'), ('Admin') ON CONFLICT (name) DO NOTHING;

-- Admin user with proper enum values and hashed passwords
INSERT INTO employees (first_name, last_name, email, password, employment_type, joining_date, department_id, role_id, status)
VALUES ('Admin', 'User', 'admin@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/Ee.', 'FULL_TIME', '2023-01-01', 1, 4, 'ACTIVE');

-- Employee user with proper enum values and hashed passwords
INSERT INTO employees (first_name, last_name, email, password, employment_type, joining_date, department_id, role_id, status)
VALUES ('John', 'Doe', 'john.doe@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/Ee.', 'FULL_TIME', '2023-01-01', 1, 1, 'ACTIVE');

