# HRMS (Human Resource Management System)

A comprehensive Human Resource Management System built with FastAPI (backend) and React (frontend).

## 🚀 Features

### Admin Features
- **Employee Management**: Add, edit, delete, and view employee records
- **Attendance Management**: Monitor employee attendance and generate reports
- **Payroll Management**: Manage salaries, generate payslips, and handle payroll processing
- **Performance Management**: Conduct performance reviews and set employee goals
- **Leave Management**: Approve/reject leave requests and manage leave policies
- **Dashboard Analytics**: View comprehensive HR analytics and reports

### Employee Features
- **Personal Dashboard**: View personal information and statistics
- **Attendance Tracking**: Clock in/out and view attendance history
- **Leave Requests**: Submit and track leave requests
- **Payroll Information**: View payslips and salary information
- **Performance Reviews**: View performance evaluations and goals

## 🛠️ Technology Stack

### Backend
- **FastAPI**: Modern, fast web framework for building APIs
- **PostgreSQL**: Robust relational database
- **SQLAlchemy**: Python SQL toolkit and ORM
- **Alembic**: Database migration tool
- **JWT**: JSON Web Tokens for authentication
- **Pydantic**: Data validation using Python type annotations

### Frontend
- **React**: JavaScript library for building user interfaces
- **React Router**: Declarative routing for React
- **Axios**: Promise-based HTTP client
- **CSS3**: Modern styling with responsive design

### DevOps
- **Docker**: Containerization platform
- **Docker Compose**: Multi-container Docker applications
- **pgAdmin**: PostgreSQL administration tool

## 📋 Prerequisites

- Docker and Docker Compose
- Node.js (v14 or higher)
- Python 3.8+
- Git

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone <your-repo-url>
cd hrms-app
```

### 2. Environment Setup
```bash
# Copy environment file
cp backend/.env.example backend/.env

# Update the .env file with your configuration
```

### 3. Start with Docker (Recommended)
```bash
# Start all services
docker-compose up -d

# Seed the database
docker-compose exec backend python create_tables.py
```

### 4. Manual Setup (Alternative)

#### Backend Setup
```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up database
python create_tables.py

# Start the backend server
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

#### Frontend Setup
```bash
cd frontend

# Install dependencies
npm install

# Start the development server
npm start
```

## 🔑 Default Login Credentials

### Admin Account
- **Email**: admin@example.com
- **Password**: admin123

### Employee Account
- **Email**: john.doe@example.com
- **Password**: employee123

## 📚 API Documentation

Once the backend is running, you can access the interactive API documentation at:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🌐 Application URLs

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **pgAdmin**: http://localhost:5050 (admin@admin.com / admin)

## 📁 Project Structure

```
hrms-app/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   └── v1/
│   │   │       ├── auth.py
│   │   │       └── auth_simple.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   ├── database.py
│   │   │   └── security.py
│   │   ├── models/
│   │   │   ├── attendance.py
│   │   │   ├── employee.py
│   │   │   ├── payroll.py
│   │   │   └── performance.py
│   │   ├── schemas/
│   │   │   └── auth.py
│   │   └── main.py
│   ├── requirements.txt
│   ├── create_tables.py
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   │   ├── useApi.js
│   │   │   └── useAuth.js
│   │   ├── pages/
│   │   │   ├── Dashboard.js
│   │   │   └── Login.js
│   │   ├── utils/
│   │   │   └── api.js
│   │   └── App.js
│   ├── package.json
│   └── public/
├── scripts/
│   └── seed_data.sql
├── docker-compose.yml
└── README.md
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the backend directory:

```env
# Database
DATABASE_URL=postgresql://hrms_user:hrms_password@localhost:5432/hrms_db

# Security
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# CORS
ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

### Frontend Configuration

Update `src/utils/api.js` for production:

```javascript
const API_BASE_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8000';
```

## 🧪 Testing

### Backend Testing
```bash
cd backend
python -m pytest tests/
```

### Frontend Testing
```bash
cd frontend
npm test
```

## 🚀 Deployment

### Production Deployment

1. **Backend Deployment** (Heroku/AWS/DigitalOcean)
   ```bash
   # Set environment variables
   export DATABASE_URL=your-production-db-url
   export SECRET_KEY=your-production-secret-key
   
   # Deploy using your preferred platform
   ```

2. **Frontend Deployment** (Netlify/Vercel)
   ```bash
   # Build the application
   npm run build
   
   # Set environment variable
   REACT_APP_BACKEND_URL=your-backend-url
   ```

### Docker Production
```bash
# Build and run in production mode
docker-compose -f docker-compose.prod.yml up -d
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

If you encounter any issues or have questions:

1. Check the [Issues](../../issues) page
2. Create a new issue with detailed information
3. Contact the development team

## 🔄 Version History

- **v1.0.0** - Initial release with core HRMS functionality
- **v1.1.0** - Enhanced authentication and CORS fixes
- **v1.2.0** - Improved UI/UX and performance optimizations

## 🙏 Acknowledgments

- FastAPI team for the excellent web framework
- React team for the powerful frontend library
- PostgreSQL team for the robust database system
- All contributors who helped improve this project

---

**Built with ❤️ by the HRMS Development Team**

