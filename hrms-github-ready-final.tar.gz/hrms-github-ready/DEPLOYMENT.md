# HRMS Deployment Guide

This guide covers different deployment options for the HRMS application.

## 🚀 Quick Start (Local Development)

### Prerequisites
- Docker and Docker Compose
- Git

### Steps
1. Clone the repository
```bash
git clone <your-repo-url>
cd hrms-app
```

2. Start with Docker
```bash
docker-compose up -d
```

3. Access the application
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/docs
- pgAdmin: http://localhost:5050

## 🌐 Production Deployment

### Option 1: Cloud Platform Deployment

#### Backend Deployment (Heroku)

1. **Prepare for Heroku**
```bash
# Install Heroku CLI
# Create Procfile in backend directory
echo "web: uvicorn app.main:app --host 0.0.0.0 --port \$PORT" > backend/Procfile
```

2. **Deploy to Heroku**
```bash
# Create Heroku app
heroku create your-hrms-backend

# Add PostgreSQL addon
heroku addons:create heroku-postgresql:hobby-dev

# Set environment variables
heroku config:set SECRET_KEY=your-production-secret-key
heroku config:set ALGORITHM=HS256
heroku config:set ACCESS_TOKEN_EXPIRE_MINUTES=30
heroku config:set ALLOWED_ORIGINS=https://your-frontend-domain.com

# Deploy
git subtree push --prefix backend heroku main
```

#### Frontend Deployment (Netlify)

1. **Build the frontend**
```bash
cd frontend
npm run build
```

2. **Deploy to Netlify**
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=build

# Set environment variable
# In Netlify dashboard, add:
# REACT_APP_BACKEND_URL=https://your-backend-url.herokuapp.com
```

### Option 2: VPS Deployment

#### Server Setup (Ubuntu 20.04+)

1. **Install dependencies**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install Nginx
sudo apt install nginx -y
```

2. **Deploy application**
```bash
# Clone repository
git clone <your-repo-url>
cd hrms-app

# Create production environment file
cp backend/.env.example backend/.env
# Edit .env with production values

# Start services
docker-compose -f docker-compose.prod.yml up -d
```

3. **Configure Nginx**
```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/hrms
```

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/hrms /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

4. **SSL Certificate (Let's Encrypt)**
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com
```

### Option 3: AWS Deployment

#### Using AWS ECS

1. **Build and push Docker images**
```bash
# Build backend image
docker build -t hrms-backend ./backend

# Build frontend image
docker build -t hrms-frontend ./frontend

# Tag and push to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.us-east-1.amazonaws.com
docker tag hrms-backend:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/hrms-backend:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/hrms-backend:latest
```

2. **Create ECS task definition**
3. **Set up RDS PostgreSQL instance**
4. **Configure Application Load Balancer**
5. **Deploy ECS service**

## 🔧 Environment Configuration

### Production Environment Variables

#### Backend (.env)
```env
DATABASE_URL=postgresql://user:password@host:port/database
SECRET_KEY=your-super-secure-secret-key
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
ALLOWED_ORIGINS=https://your-frontend-domain.com
DEBUG=False
ENVIRONMENT=production
```

#### Frontend
```env
REACT_APP_BACKEND_URL=https://your-backend-domain.com
REACT_APP_ENVIRONMENT=production
```

## 📊 Database Setup

### Production Database Migration

1. **Create database**
```sql
CREATE DATABASE hrms_db;
CREATE USER hrms_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE hrms_db TO hrms_user;
```

2. **Run migrations**
```bash
cd backend
python create_tables.py
```

3. **Seed initial data**
```bash
# Connect to database and run seed_data.sql
psql -h hostname -U hrms_user -d hrms_db -f scripts/seed_data.sql
```

## 🔒 Security Considerations

### Production Security Checklist

- [ ] Change default SECRET_KEY
- [ ] Use strong database passwords
- [ ] Enable HTTPS/SSL
- [ ] Configure proper CORS origins
- [ ] Set up database backups
- [ ] Enable logging and monitoring
- [ ] Use environment variables for secrets
- [ ] Configure firewall rules
- [ ] Regular security updates
- [ ] Implement rate limiting

### Recommended Security Headers

```nginx
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
```

## 📈 Monitoring and Logging

### Application Monitoring

1. **Set up logging**
```python
import logging
logging.basicConfig(level=logging.INFO)
```

2. **Health check endpoints**
```python
@app.get("/health")
async def health_check():
    return {"status": "healthy"}
```

3. **Database monitoring**
- Monitor connection pool usage
- Track query performance
- Set up alerts for failures

## 🔄 CI/CD Pipeline

### GitHub Actions Example

```yaml
name: Deploy HRMS

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Deploy to production
      run: |
        # Add your deployment commands here
```

## 🆘 Troubleshooting

### Common Issues

1. **CORS errors**
   - Check ALLOWED_ORIGINS in backend .env
   - Verify frontend API URL configuration

2. **Database connection issues**
   - Verify DATABASE_URL format
   - Check database server status
   - Confirm network connectivity

3. **Authentication problems**
   - Verify SECRET_KEY is set
   - Check token expiration settings
   - Validate user credentials

### Logs and Debugging

```bash
# View Docker logs
docker-compose logs backend
docker-compose logs frontend

# Database logs
docker-compose logs postgres

# Nginx logs
sudo tail -f /var/log/nginx/error.log
```

## 📞 Support

For deployment issues:
1. Check the troubleshooting section
2. Review application logs
3. Create an issue on GitHub
4. Contact the development team

---

**Happy Deploying! 🚀**

