import axios from "axios";
export function useApi() {
  // Custom hook for API calls
  return axios;
}
