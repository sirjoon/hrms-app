import { useState, useEffect } from "react";
import { authAPI } from "../utils/api";

export function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      const token = localStorage.getItem("token");
      if (token) {
        try {
          // Try to decode JWT to get user info
          const payload = JSON.parse(atob(token.split(".")[1]));
          setUser({ 
            id: payload.sub, 
            email: payload.email || payload.username,
            role: payload.role || 'employee'
          });
        } catch (error) {
          console.error("Error decoding token:", error);
          // If token is invalid, remove it
          localStorage.removeItem("token");
          localStorage.removeItem("tokenType");
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (token) => {
    try {
      localStorage.setItem("token", token);
      localStorage.setItem("tokenType", "bearer");
      
      // Decode JWT to get user info
      const payload = JSON.parse(atob(token.split(".")[1]));
      const userData = { 
        id: payload.sub, 
        email: payload.email || payload.username,
        role: payload.role || 'employee'
      };
      
      setUser(userData);
      return userData;
    } catch (error) {
      console.error("Error processing login token:", error);
      throw new Error("Invalid token received");
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("tokenType");
    setUser(null);
  };

  const isAuthenticated = () => {
    return !!user && !!localStorage.getItem("token");
  };

  const isAdmin = () => {
    return user?.role === 'admin';
  };

  const getToken = () => {
    return localStorage.getItem("token");
  };

  return { 
    user, 
    login, 
    logout, 
    loading, 
    isAuthenticated, 
    isAdmin, 
    getToken 
  };
}

