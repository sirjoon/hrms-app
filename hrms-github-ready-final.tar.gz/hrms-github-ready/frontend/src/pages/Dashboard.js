import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { employeeAPI, attendanceAPI, adminAPI } from '../utils/api';

const Dashboard = () => {
  const { user, logout, isAdmin } = useAuth();
  const [employees, setEmployees] = useState([]);
  const [attendanceLogs, setAttendanceLogs] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError('');

        if (isAdmin()) {
          // Admin can see all data
          try {
            const employeesData = await employeeAPI.getAll();
            setEmployees(employeesData);
          } catch (err) {
            console.error('Error fetching employees:', err);
          }

          try {
            const analyticsData = await adminAPI.getAnalytics();
            setAnalytics(analyticsData);
          } catch (err) {
            console.error('Error fetching analytics:', err);
          }
        }

        // Both admin and employee can see attendance logs
        try {
          const logsData = await attendanceAPI.getLogs();
          setAttendanceLogs(logsData);
        } catch (err) {
          console.error('Error fetching attendance logs:', err);
        }

      } catch (error) {
        console.error('Dashboard error:', error);
        setError('Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchData();
    }
  }, [user, isAdmin]);

  const handleClockIn = async () => {
    try {
      const clockInData = {
        employee_id: user.id,
        date: new Date().toISOString().split('T')[0],
        clock_in: new Date().toTimeString().split(' ')[0],
        status: 'present'
      };
      
      await attendanceAPI.clockIn(clockInData);
      alert('Clocked in successfully!');
      
      // Refresh attendance logs
      const logsData = await attendanceAPI.getLogs();
      setAttendanceLogs(logsData);
    } catch (error) {
      console.error('Clock in error:', error);
      alert('Failed to clock in: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleClockOut = async () => {
    try {
      const clockOutData = {
        employee_id: user.id,
        date: new Date().toISOString().split('T')[0],
        clock_out: new Date().toTimeString().split(' ')[0],
        status: 'present'
      };
      
      await attendanceAPI.clockOut(clockOutData);
      alert('Clocked out successfully!');
      
      // Refresh attendance logs
      const logsData = await attendanceAPI.getLogs();
      setAttendanceLogs(logsData);
    } catch (error) {
      console.error('Clock out error:', error);
      alert('Failed to clock out: ' + (error.response?.data?.detail || error.message));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">HRMS Dashboard</h1>
              <p className="text-gray-600">Welcome, {user?.email} ({user?.role})</p>
            </div>
            <button
              onClick={logout}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        )}

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <button
              onClick={handleClockIn}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg"
            >
              Clock In
            </button>
            <button
              onClick={handleClockOut}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg"
            >
              Clock Out
            </button>
            <button className="bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-3 rounded-lg">
              Request Leave
            </button>
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg">
              View Payslip
            </button>
          </div>
        </div>

        {/* Admin Section */}
        {isAdmin() && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Admin Panel</h2>
            
            {/* Analytics */}
            {analytics && (
              <div className="bg-white p-6 rounded-lg shadow mb-4">
                <h3 className="text-lg font-semibold mb-2">Analytics</h3>
                <pre className="text-sm text-gray-600">{JSON.stringify(analytics, null, 2)}</pre>
              </div>
            )}

            {/* Employees List */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-semibold mb-4">Employees ({employees.length})</h3>
              {employees.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Email
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Role
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {employees.map((employee) => (
                        <tr key={employee.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {employee.id}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {employee.first_name} {employee.last_name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {employee.email}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {employee.role}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-gray-500">No employees found or unable to load employee data.</p>
              )}
            </div>
          </div>
        )}

        {/* Attendance Logs */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Recent Attendance</h3>
          {attendanceLogs.length > 0 ? (
            <div className="space-y-2">
              {attendanceLogs.slice(0, 5).map((log, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                  <span>{log.date}</span>
                  <span>{log.clock_in} - {log.clock_out || 'Not clocked out'}</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    log.status === 'present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {log.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No attendance logs found or unable to load attendance data.</p>
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;

