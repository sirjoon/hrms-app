import axios from 'axios';

// Base URL for the API
const BASE_URL = 'https://8000-it3iv1cbhe69hk2vi5vt8-39d40d47.manusvm.computer';

// Create axios instance
const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  withCredentials: false, // Disable credentials to avoid CORS issues
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('tokenType');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API calls
export const authAPI = {
  login: async (email, password) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },
  
  getCurrentUser: async () => {
    const response = await api.get('/auth/me');
    return response.data;
  },
};

// Employee API calls
export const employeeAPI = {
  getAll: async () => {
    const response = await api.get('/employees/');
    return response.data;
  },
  
  getById: async (id) => {
    const response = await api.get(`/employees/${id}`);
    return response.data;
  },
  
  create: async (employeeData) => {
    const response = await api.post('/employees/', employeeData);
    return response.data;
  },
  
  update: async (id, employeeData) => {
    const response = await api.put(`/employees/${id}`, employeeData);
    return response.data;
  },
  
  delete: async (id) => {
    const response = await api.delete(`/employees/${id}`);
    return response.data;
  },
};

// Attendance API calls
export const attendanceAPI = {
  clockIn: async (attendanceData) => {
    const response = await api.post('/attendance/clock-in', attendanceData);
    return response.data;
  },
  
  clockOut: async (attendanceData) => {
    const response = await api.post('/attendance/clock-out', attendanceData);
    return response.data;
  },
  
  getLogs: async () => {
    const response = await api.get('/attendance/logs');
    return response.data;
  },
  
  submitLeave: async (leaveData) => {
    const response = await api.post('/attendance/leave', leaveData);
    return response.data;
  },
  
  getHolidays: async () => {
    const response = await api.get('/attendance/holidays');
    return response.data;
  },
};

// Payroll API calls
export const payrollAPI = {
  createSalary: async (salaryData) => {
    const response = await api.post('/payroll/salary', salaryData);
    return response.data;
  },
  
  generatePayslip: async (employeeId, month) => {
    const response = await api.get(`/payroll/payslip/${employeeId}?month=${month}`);
    return response.data;
  },
};

// Performance API calls
export const performanceAPI = {
  createReview: async (reviewData) => {
    const response = await api.post('/performance/review', reviewData);
    return response.data;
  },
  
  setGoal: async (goalData) => {
    const response = await api.post('/performance/goal', goalData);
    return response.data;
  },
};

// Admin API calls
export const adminAPI = {
  getAnalytics: async () => {
    const response = await api.get('/admin/analytics');
    return response.data;
  },
  
  updateSettings: async (settingsData) => {
    const response = await api.post('/admin/settings', settingsData);
    return response.data;
  },
};

export default api;

